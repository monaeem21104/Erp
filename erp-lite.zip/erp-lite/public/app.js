(() => {
  const CURRENCY = 'EGP';
  const S = { user: null, token: localStorage.getItem('token'), lang: localStorage.getItem('lang') || 'en', page: 'dashboard', q: '' };
  const $ = (s, r = document) => r.querySelector(s);
  const t = (k) => (I18N[S.lang][k] ?? I18N.en[k] ?? k);
  const esc = (v) => String(v ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  const loc = () => (S.lang === 'ar' ? 'ar-EG' : 'en-US');
  const money = (c) => new Intl.NumberFormat(loc(), { style: 'currency', currency: CURRENCY }).format((c || 0) / 100);
  const num = (n) => new Intl.NumberFormat(loc()).format(n || 0);
  const when = (s) => s ? new Date(s.replace(' ', 'T') + 'Z').toLocaleString(loc(), { dateStyle: 'medium', timeStyle: 'short' }) : '';
  const day = (s) => new Date(s + 'T00:00:00Z').toLocaleDateString(loc(), { weekday: 'short', timeZone: 'UTC' });
  const can = (p) => S.user && (S.user.permissions.includes('*') || S.user.permissions.includes(p));
  const pname = (p) => S.lang === 'ar' && p.name_ar ? p.name_ar : p.name_en;

  // ---------- centralized API client ----------
  async function api(method, path, body) {
    let r;
    try {
      r = await fetch('/api' + path, { method, headers: { 'Content-Type': 'application/json', ...(S.token ? { Authorization: 'Bearer ' + S.token } : {}) }, body: body ? JSON.stringify(body) : undefined });
    } catch { throw new Error('Network error'); }
    const j = await r.json().catch(() => ({}));
    if (r.status === 401 && S.token) { S.token = null; S.user = null; localStorage.removeItem('token'); render(); }
    if (!r.ok) throw new Error(j.error || 'Error ' + r.status);
    return j;
  }
  const toast = (msg, bad) => { const d = document.createElement('div'); d.className = 'toast' + (bad ? ' bad' : ''); d.textContent = msg; document.body.append(d); setTimeout(() => d.remove(), 3200); };
  const guard = (fn) => async (...a) => { try { await fn(...a); } catch (e) { toast(e.message, true); } };

  function setLang(l) {
    S.lang = l; localStorage.setItem('lang', l);
    document.documentElement.lang = l; document.documentElement.dir = l === 'ar' ? 'rtl' : 'ltr';
    document.title = t('app');
  }

  // ---------- modal ----------
  function modal(title, html, onSubmit) {
    const m = document.createElement('div'); m.className = 'modal';
    m.innerHTML = `<form class="box"><h2>${esc(title)}</h2>${html}<div class="err"></div>
      <div class="row" style="margin-top:14px"><button class="btn pri" type="submit">${t('save')}</button><button class="btn" type="button" data-close>${t('cancel')}</button></div></form>`;
    document.body.append(m);
    m.addEventListener('click', e => { if (e.target === m || e.target.matches('[data-close]')) m.remove(); });
    $('form', m).addEventListener('submit', async e => {
      e.preventDefault(); const f = Object.fromEntries(new FormData(e.target));
      try { await onSubmit(f, m); m.remove(); toast(t('saved')); go(S.page); } catch (er) { $('.err', m).textContent = er.message; }
    });
    const first = $('input,select', m); if (first) first.focus();
    return m;
  }
  const field = (name, label, val = '', type = 'text', extra = '') => `<label>${t(label)}</label><input name="${name}" type="${type}" value="${esc(val)}" ${extra}>`;

  // ---------- views ----------
  function authView(mode = 'login', msg = '') {
    $('#root').innerHTML = `<div class="auth"><form class="box" id="authForm">
      <div class="row" style="justify-content:space-between"><div class="brand"><span class="logo">E</span>${t('app')}</div><button type="button" class="btn sm" data-lang>${t('language')}</button></div>
      <h2 style="margin-top:18px">${t(mode)}</h2>${msg ? `<div class="note">${esc(msg)}</div>` : ''}
      ${mode === 'register' ? field('name', 'name', '', 'text', 'required maxlength=100') : ''}
      ${field('email', 'email', '', 'email', 'required autocomplete=username')}
      ${field('password', 'password', '', 'password', `required minlength=${mode === 'register' ? 10 : 1} autocomplete=${mode === 'register' ? 'new-password' : 'current-password'}`)}
      ${mode === 'register' ? `<small style="color:var(--mute)">${t('pw_hint')}</small>` : ''}
      <div class="err"></div>
      <button class="btn pri" style="width:100%;margin-top:10px" type="submit">${t(mode)}</button>
      <p style="text-align:center;color:var(--mute)">${mode === 'login' ? t('no_account') : t('have_account')} <a href="#" data-switch="${mode === 'login' ? 'register' : 'login'}">${t(mode === 'login' ? 'register' : 'login')}</a></p></form></div>`;
    $('#authForm').addEventListener('submit', async e => {
      e.preventDefault(); const f = Object.fromEntries(new FormData(e.target));
      try {
        if (mode === 'register') { await api('POST', '/auth/register', f); authView('login', t('registered')); return; }
        const r = await api('POST', '/auth/login', f); S.token = r.token; localStorage.setItem('token', r.token); S.user = r.user;
        api('PUT', '/me/lang', { lang: S.lang }).catch(() => {}); S.page = firstPage(); render();
      } catch (er) { $('.err').textContent = er.message; }
    });
  }

  const NAV = [
    ['dashboard', 'dashboard.read'], ['products', 'products.read'], ['movements', 'products.read'], ['sales', 'sales.read'], ['purchases', 'purchases.read'],
    ['customers', 'customers.read'], ['suppliers', 'suppliers.read'], ['users', 'users.manage'], ['audit', 'users.manage']
  ];
  const ICON = { dashboard: '▦', products: '▤', movements: '⇄', sales: '↗', purchases: '↙', customers: '☺', suppliers: '⚒', users: '⚿', audit: '☰' };
  const firstPage = () => (NAV.find(n => can(n[1])) || ['none'])[0];

  function appView() {
    const items = NAV.filter(n => can(n[1]));
    $('#root').innerHTML = `<div class="app"><aside class="side" id="side">
      <div class="brand"><span class="logo">E</span>${t('app')}</div>
      <nav class="nav">${items.map(([p]) => `<a data-page="${p}" class="${S.page === p ? 'on' : ''}"><span>${ICON[p]}</span>${t(p)}</a>`).join('')}</nav>
      <div class="me"><b>${esc(S.user.name)}</b><small>${esc(S.user.email)} · ${t('r_' + S.user.role)}</small>
        <div class="row" style="margin-top:8px"><button class="btn sm" data-lang>${t('language')}</button><button class="btn sm" data-logout>${t('logout')}</button></div></div>
    </aside><main class="main"><div class="top"><div class="row"><button class="btn menu-btn" data-menu>☰</button><h1 id="title"></h1></div><div id="tools" class="row"></div></div><div id="page"><div class="empty">${t('loading')}</div></div></main></div>`;
    go(S.page);
  }

  async function go(page) {
    S.page = page;
    document.querySelectorAll('.nav a').forEach(a => a.classList.toggle('on', a.dataset.page === page));
    $('#side')?.classList.remove('open');
    if (!$('#page')) return;
    $('#title').textContent = t(page === 'none' ? 'app' : page); $('#tools').innerHTML = '';
    try { $('#page').innerHTML = await (PAGES[page] || PAGES.none)(); } catch (e) { $('#page').innerHTML = `<div class="card empty">${esc(e.message)}</div>`; }
  }
  const tools = (html) => { $('#tools').innerHTML = html; };
  const searchBox = () => `<input class="grow" id="q" placeholder="${t('search')}" value="${esc(S.q)}" style="min-width:160px">`;
  const table = (heads, rows) => rows.length
    ? `<div class="tw"><table><thead><tr>${heads.map(h => `<th>${h}</th>`).join('')}</tr></thead><tbody>${rows.join('')}</tbody></table></div>`
    : `<div class="empty">${t('empty')}</div>`;
  const st = (s) => `<span class="badge ${{ received: 'ok', delivered: 'ok', active: 'ok', ordered: 'warn', cancelled: 'bad', suspended: 'bad' }[s] || ''}">${t(s)}</span>`;

  const PAGES = {
    none: async () => `<div class="card note">${t('pending_access')}</div>`,

    dashboard: async () => {
      const d = await api('GET', '/dashboard');
      const max = Math.max(1, ...d.sales_by_day.map(x => x.t));
      return `<div class="grid stats">
        <div class="card stat dark"><div class="l">${t('revenue')}</div><div class="v">${money(d.revenue_cents)}</div></div>
        <div class="card stat"><div class="l">${t('expenses')}</div><div class="v">${money(d.expenses_cents)}</div></div>
        <div class="card stat green"><div class="l">${t('inv_value')}</div><div class="v">${money(d.inventory_value_cents)}</div></div>
        <div class="card stat"><div class="l">${t('sales_orders')}</div><div class="v">${num(d.sales_orders)}</div></div>
        <div class="card stat"><div class="l">${t('pending_po')}</div><div class="v">${num(d.pending_purchase_orders)}</div></div>
        <div class="card stat"><div class="l">${t('products')}</div><div class="v">${num(d.products)}</div></div></div>
      <div class="grid two"><div class="card"><h2>${t('sales_7d')}</h2>${d.sales_by_day.length
        ? `<div class="chart">${d.sales_by_day.map(x => `<div class="b"><span>${money(x.t).replace(/\.00|٫٠٠/, '')}</span><i style="height:${Math.round(x.t / max * 100)}%"></i><span>${day(x.d)}</span></div>`).join('')}</div>`
        : `<div class="empty">${t('empty')}</div>`}</div>
      <div class="card"><h2>${t('low_stock')}</h2>${d.low_stock.length ? table([t('sku'), t('name'), t('stock'), t('reorder')],
        d.low_stock.map(p => `<tr><td>${esc(p.sku)}</td><td>${esc(pname(p))}</td><td><span class="badge bad">${num(p.stock)}</span></td><td>${num(p.reorder_level)}</td></tr>`)) : `<div class="empty">${t('no_low')}</div>`}</div></div>
      <div class="card" style="margin-top:14px"><h2>${t('recent')}</h2>${movTable(d.recent_movements)}</div>`;
    },

    products: async () => {
      const list = await api('GET', '/products?q=' + encodeURIComponent(S.q));
      tools(searchBox() + (can('products.write') ? `<button class="btn pri" data-act="prod-new">+ ${t('add')}</button>` : ''));
      return `<div class="card">${table([t('sku'), t('name'), t('unit'), t('price'), t('cost'), t('stock'), t('reorder'), ''],
        list.map(p => `<tr><td>${esc(p.sku)}</td><td>${esc(pname(p))}</td><td>${esc(p.unit)}</td><td>${money(p.price_cents)}</td><td>${money(p.cost_cents)}</td>
          <td><span class="badge ${p.stock <= p.reorder_level ? 'bad' : 'ok'}">${num(p.stock)}</span></td><td>${num(p.reorder_level)}</td>
          <td>${can('products.write') ? `<button class="btn sm" data-act="prod-edit" data-id="${p.id}">${t('edit')}</button> <button class="btn sm" data-act="prod-adj" data-id="${p.id}">${t('adjust')}</button>` : ''}</td></tr>`))}</div>`;
    },
    movements: async () => `<div class="card">${movTable(await api('GET', '/movements'))}</div>`,

    customers: () => partyPage('customers'), suppliers: () => partyPage('suppliers'),

    sales: async () => {
      const l = await api('GET', '/sales');
      tools(can('sales.write') ? `<button class="btn pri" data-act="sale-new">+ ${t('new_sale')}</button>` : '');
      return `<div class="card">${table(['#', t('customer'), t('total'), t('status'), t('date')],
        l.map(o => `<tr><td>SO-${o.id}</td><td>${esc(o.customer)}</td><td>${money(o.total_cents)}</td><td>${st(o.status)}</td><td>${when(o.created_at)}</td></tr>`))}</div>`;
    },
    purchases: async () => {
      const l = await api('GET', '/purchases');
      tools(can('purchases.write') ? `<button class="btn pri" data-act="po-new">+ ${t('new_po')}</button>` : '');
      return `<div class="card">${table(['#', t('supplier'), t('total'), t('status'), t('date'), ''],
        l.map(o => `<tr><td>PO-${o.id}</td><td>${esc(o.supplier)}</td><td>${money(o.total_cents)}</td><td>${st(o.status)}</td><td>${when(o.created_at)}</td>
          <td>${o.status === 'ordered' && can('purchases.write') ? `<button class="btn sm pri" data-act="po-recv" data-id="${o.id}">${t('receive')}</button> <button class="btn sm danger" data-act="po-cancel" data-id="${o.id}">${t('cancel_po')}</button>` : ''}</td></tr>`))}</div>`;
    },
    users: async () => {
      const l = await api('GET', '/users');
      tools(`<button class="btn pri" data-act="user-new">+ ${t('new_user')}</button>`);
      const roles = ['admin', 'manager', 'staff', 'user'];
      return `<div class="card">${table([t('name'), t('email'), t('role'), t('status'), ''],
        l.map(u => `<tr><td>${esc(u.name)}</td><td>${esc(u.email)}</td>
          <td><select data-act="user-role" data-id="${u.id}" style="width:auto">${roles.map(r => `<option value="${r}" ${r === u.role ? 'selected' : ''}>${t('r_' + r)}</option>`).join('')}</select></td>
          <td>${st(u.status)}</td><td><button class="btn sm" data-act="user-toggle" data-id="${u.id}" data-status="${u.status}">${u.status === 'active' ? t('suspended') : t('active')}</button>
          <button class="btn sm" data-act="user-pw" data-id="${u.id}">${t('reset_pw')}</button></td></tr>`))}</div>`;
    },
    audit: async () => {
      const l = await api('GET', '/audit');
      return `<div class="card">${table([t('date'), t('actor'), t('action'), t('target')],
        l.map(a => `<tr><td>${when(a.created_at)}</td><td>${esc(a.actor || '—')}</td><td>${esc(a.action)}</td><td>${esc(a.target || '')}</td></tr>`))}</div>`;
    }
  };

  function movTable(l) {
    return table([t('date'), t('sku'), t('name'), t('type'), t('qty'), t('ref')], l.map(m =>
      `<tr><td>${when(m.created_at)}</td><td>${esc(m.sku)}</td><td>${esc(pname(m))}</td><td>${t(m.type === 'opening' ? 'opening_t' : m.type)}</td>
       <td><span class="badge ${m.qty < 0 ? 'bad' : 'ok'}">${m.qty > 0 ? '+' : ''}${num(m.qty)}</span></td><td>${esc(m.ref || '')}</td></tr>`));
  }
  async function partyPage(kind) {
    const l = await api('GET', `/${kind}?q=` + encodeURIComponent(S.q)); const w = can(kind + '.write');
    tools(searchBox() + (w ? `<button class="btn pri" data-act="party-new" data-kind="${kind}">+ ${t('add')}</button>` : ''));
    S.cache = { ...(S.cache || {}), [kind]: l };
    return `<div class="card">${table([t('name'), t('phone'), t('email'), t('address'), ''], l.map(c =>
      `<tr><td>${esc(c.name)}</td><td>${esc(c.phone)}</td><td>${esc(c.email)}</td><td>${esc(c.address)}</td>
       <td>${w ? `<button class="btn sm" data-act="party-edit" data-kind="${kind}" data-id="${c.id}">${t('edit')}</button> <button class="btn sm danger" data-act="party-del" data-kind="${kind}" data-id="${c.id}">${t('delete')}</button>` : ''}</td></tr>`))}</div>`;
  }

  // ---------- actions ----------
  const partyForm = (c = {}) => field('name', 'name', c.name, 'text', 'required') + field('phone', 'phone', c.phone) + field('email', 'email', c.email, 'email') + field('address', 'address', c.address);
  const prodForm = (p = {}, isNew) => field('sku', 'sku', p.sku, 'text', 'required') + field('name_en', 'name_en', p.name_en, 'text', 'required') + field('name_ar', 'name_ar', p.name_ar) +
    field('unit', 'unit', p.unit || 'pcs') + field('price', 'price', p.price_cents != null ? p.price_cents / 100 : '', 'number', 'step=0.01 min=0 required') +
    field('cost', 'cost', p.cost_cents != null ? p.cost_cents / 100 : 0, 'number', 'step=0.01 min=0') + field('reorder_level', 'reorder', p.reorder_level ?? 0, 'number', 'min=0') +
    (isNew ? field('stock', 'opening', 0, 'number', 'min=0') : '');
  const lineRow = (prods, costField) => `<div class="row line" style="margin-top:6px"><select name="product_id" class="grow">${prods.map(p => `<option value="${p.id}">${esc(p.sku)} — ${esc(pname(p))}${costField ? '' : ` (${num(p.stock)})`}</option>`).join('')}</select>
    <input name="qty" type="number" min="1" value="1" style="width:80px" aria-label="${t('qty')}">${costField ? `<input name="cost" type="number" min="0" step="0.01" placeholder="${t('unit_cost')}" style="width:110px" required>` : ''}</div>`;
  function linesModal(title, partyLabel, parties, prods, costField, submit) {
    const m = modal(title, `<label>${t(partyLabel)}</label><select name="party">${parties.map(p => `<option value="${p.id}">${esc(p.name)}</option>`).join('')}</select>
      <label>${t('item')}</label><div id="lines">${lineRow(prods, costField)}</div><button type="button" class="btn sm" data-addline style="margin-top:8px">+ ${t('add_line')}</button>`,
      async (f, mm) => {
        const lines = [...mm.querySelectorAll('.line')].map(r => ({ product_id: +$('[name=product_id]', r).value, qty: +$('[name=qty]', r).value, ...(costField ? { unit_cost: +$('[name=cost]', r).value } : {}) }));
        await submit(+f.party, lines);
      });
    m.addEventListener('click', e => { if (e.target.matches('[data-addline]')) $('#lines', m).insertAdjacentHTML('beforeend', lineRow(prods, costField)); });
  }

  const ACT = {
    'prod-new': () => modal(t('add'), prodForm({}, true), f => api('POST', '/products', f)),
    'prod-edit': async (el) => { const p = (await api('GET', '/products')).find(x => x.id == el.dataset.id); modal(t('edit'), prodForm(p), f => api('PUT', '/products/' + p.id, f)); },
    'prod-adj': (el) => modal(t('adjust'), field('qty', 'adjust_qty', '', 'number', 'required step=1') + field('reason', 'reason', '', 'text', 'required'), f => api('POST', `/products/${el.dataset.id}/adjust`, { qty: +f.qty, reason: f.reason })),
    'party-new': (el) => modal(t('add'), partyForm(), f => api('POST', '/' + el.dataset.kind, f)),
    'party-edit': (el) => { const c = S.cache[el.dataset.kind].find(x => x.id == el.dataset.id); modal(t('edit'), partyForm(c), f => api('PUT', `/${el.dataset.kind}/${c.id}`, f)); },
    'party-del': async (el) => { if (confirm(t('confirm_delete'))) { await api('DELETE', `/${el.dataset.kind}/${el.dataset.id}`); go(S.page); } },
    'sale-new': async () => { const [c, p] = await Promise.all([api('GET', '/customers'), api('GET', '/products')]); linesModal(t('new_sale'), 'customer', c, p.filter(x => x.stock > 0), false, (id, items) => api('POST', '/sales', { customer_id: id, items })); },
    'po-new': async () => { const [s, p] = await Promise.all([api('GET', '/suppliers'), api('GET', '/products')]); linesModal(t('new_po'), 'supplier', s, p, true, (id, items) => api('POST', '/purchases', { supplier_id: id, items })); },
    'po-recv': async (el) => { await api('POST', `/purchases/${el.dataset.id}/receive`, {}); toast(t('saved')); go(S.page); },
    'po-cancel': async (el) => { await api('POST', `/purchases/${el.dataset.id}/cancel`, {}); toast(t('saved')); go(S.page); },
    'user-new': () => modal(t('new_user'), field('name', 'name', '', 'text', 'required') + field('email', 'email', '', 'email', 'required') + field('password', 'password', '', 'password', 'required minlength=10') +
      `<label>${t('role')}</label><select name="role">${['user', 'staff', 'manager', 'admin'].map(r => `<option value="${r}">${t('r_' + r)}</option>`).join('')}</select>`, f => api('POST', '/users', f)),
    'user-toggle': async (el) => { await api('PUT', '/users/' + el.dataset.id, { status: el.dataset.status === 'active' ? 'suspended' : 'active' }); go(S.page); },
    'user-pw': (el) => modal(t('reset_pw'), field('password', 'new_pw', '', 'password', 'required minlength=10'), f => api('POST', `/users/${el.dataset.id}/password`, f))
  };

  // ---------- events ----------
  document.addEventListener('click', guard(async (e) => {
    const el = e.target.closest('[data-act],[data-page],[data-lang],[data-logout],[data-switch],[data-menu]'); if (!el) return;
    if (el.dataset.page) { S.q = ''; go(el.dataset.page); }
    else if (el.dataset.act && el.tagName !== 'SELECT') await ACT[el.dataset.act](el);
    else if (el.dataset.lang !== undefined) {
      setLang(S.lang === 'en' ? 'ar' : 'en');
      if (S.user) { api('PUT', '/me/lang', { lang: S.lang }).catch(() => {}); appView(); } else authView();
    }
    else if (el.dataset.logout !== undefined) { await api('POST', '/auth/logout', {}).catch(() => {}); S.token = null; S.user = null; localStorage.removeItem('token'); render(); }
    else if (el.dataset.switch) { e.preventDefault(); authView(el.dataset.switch); }
    else if (el.dataset.menu !== undefined) $('#side').classList.toggle('open');
  }));
  document.addEventListener('change', guard(async (e) => {
    if (e.target.matches('[data-act=user-role]')) { await api('PUT', '/users/' + e.target.dataset.id, { role: e.target.value }); toast(t('saved')); }
  }));
  let timer; document.addEventListener('input', (e) => {
    if (e.target.id === 'q') { clearTimeout(timer); S.q = e.target.value; timer = setTimeout(async () => { const keep = $('#q'); const v = keep.value; try { $('#page').innerHTML = await PAGES[S.page](); } catch {} const q = $('#q'); if (q) { q.focus(); q.setSelectionRange(v.length, v.length); } }, 250); }
  });

  async function render() {
    setLang(S.lang);
    if (S.token && !S.user) { try { S.user = await api('GET', '/me'); setLang(S.user.lang); } catch { S.token = null; } }
    if (!S.user) return authView();
    if (!NAV.some(n => n[0] === S.page && can(n[1]))) S.page = firstPage();
    appView();
  }
  render();
})();
