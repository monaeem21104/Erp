const { test, before, after } = require('node:test');
const assert = require('node:assert/strict');
const { open } = require('../server/db');
const { createApp } = require('../server/index');

let server, base, db, admin, user;
const call = async (method, path, body, token) => {
  const r = await fetch(base + path, { method, headers: { 'Content-Type': 'application/json', ...(token ? { Authorization: 'Bearer ' + token } : {}) }, body: body ? JSON.stringify(body) : undefined });
  let json = null; try { json = await r.json(); } catch {}
  return { status: r.status, json };
};

before(async () => {
  process.env.ADMIN_EMAIL = 'boss@test.local'; process.env.ADMIN_PASSWORD = 'correct-horse-battery';
  db = open(':memory:');
  const app = createApp(db); app.bootstrapAdmin(() => {});
  server = app.server; await new Promise(r => server.listen(0, r));
  base = 'http://localhost:' + server.address().port;
  admin = (await call('POST', '/api/auth/login', { email: 'boss@test.local', password: 'correct-horse-battery' })).json.token;
});
after(() => server.close());

test('login works and bad password is rejected', async () => {
  assert.ok(admin);
  assert.equal((await call('POST', '/api/auth/login', { email: 'boss@test.local', password: 'wrong-password!' })).status, 401);
});

test('public registration always yields role=user and cannot reach business data or admin features', async () => {
  const reg = await call('POST', '/api/auth/register', { name: 'Eve', email: 'eve@test.local', password: 'longenoughpass', role: 'admin' });
  assert.equal(reg.status, 201);
  user = (await call('POST', '/api/auth/login', { email: 'eve@test.local', password: 'longenoughpass' })).json;
  assert.equal(user.user.role, 'user');
  for (const p of ['/api/products', '/api/dashboard', '/api/users', '/api/audit', '/api/sales'])
    assert.equal((await call('GET', p, null, user.token)).status, 403, p);
  assert.equal((await call('PUT', '/api/users/1', { role: 'admin' }, user.token)).status, 403);
  assert.equal((await call('GET', '/api/products')).status, 401);
});

test('admin promotes user to staff (read-only): can read, cannot write', async () => {
  const id = user.user.id;
  assert.equal((await call('PUT', '/api/users/' + id, { role: 'staff' }, admin)).status, 200);
  // role change revokes old sessions
  assert.equal((await call('GET', '/api/products', null, user.token)).status, 401);
  const t = (await call('POST', '/api/auth/login', { email: 'eve@test.local', password: 'longenoughpass' })).json.token;
  assert.equal((await call('GET', '/api/products', null, t)).status, 200);
  assert.equal((await call('POST', '/api/products', { sku: 'X', name_en: 'X' }, t)).status, 403);
});

test('cannot demote the last admin', async () => {
  const r = await call('PUT', '/api/users/1', { role: 'user' }, admin);
  assert.equal(r.status, 409);
});

test('purchase -> receive -> sale flow keeps inventory consistent and never goes negative', async () => {
  const p = (await call('POST', '/api/products', { sku: 'BOLT-1', name_en: 'Bolt', name_ar: 'مسمار', price: 2.5, cost: 1, reorder_level: 5 }, admin)).json;
  assert.ok(p.id);
  assert.equal((await call('POST', '/api/products', { sku: 'BOLT-1', name_en: 'dup' }, admin)).status, 409);
  const s = (await call('POST', '/api/suppliers', { name: 'Acme Steel' }, admin)).json;
  const c = (await call('POST', '/api/customers', { name: 'Factory Co' }, admin)).json;

  const po = (await call('POST', '/api/purchases', { supplier_id: s.id, items: [{ product_id: p.id, qty: 100, unit_cost: 1.2 }] }, admin)).json;
  assert.equal(po.total_cents, 12000);
  assert.equal(db.prepare('SELECT stock FROM products WHERE id=?').get(p.id).stock, 0);
  assert.equal((await call('POST', `/api/purchases/${po.id}/receive`, {}, admin)).status, 200);
  assert.equal(db.prepare('SELECT stock FROM products WHERE id=?').get(p.id).stock, 100);
  assert.equal((await call('POST', `/api/purchases/${po.id}/receive`, {}, admin)).status, 409); // no double receive

  const so = await call('POST', '/api/sales', { customer_id: c.id, items: [{ product_id: p.id, qty: 40 }] }, admin);
  assert.equal(so.status, 201); assert.equal(so.json.total_cents, 10000);
  assert.equal(db.prepare('SELECT stock FROM products WHERE id=?').get(p.id).stock, 60);

  const over = await call('POST', '/api/sales', { customer_id: c.id, items: [{ product_id: p.id, qty: 61 }] }, admin);
  assert.equal(over.status, 409);
  assert.equal(db.prepare('SELECT stock FROM products WHERE id=?').get(p.id).stock, 60); // rolled back
  assert.equal((await call('POST', `/api/products/${p.id}/adjust`, { qty: -1000, reason: 'oops' }, admin)).status, 409);

  // ledger sums to stock
  const sum = db.prepare('SELECT SUM(qty) s FROM stock_movements WHERE product_id=?').get(p.id).s;
  assert.equal(sum, 60);

  const dash = (await call('GET', '/api/dashboard', null, admin)).json;
  assert.equal(dash.revenue_cents, 10000); assert.equal(dash.expenses_cents, 12000);
  assert.equal(dash.inventory_value_cents, 60 * db.prepare('SELECT cost_cents FROM products WHERE id=?').get(p.id).cost_cents);
});

test('concurrent sales cannot oversell', async () => {
  const p = (await call('POST', '/api/products', { sku: 'RACE', name_en: 'Race', price: 1, stock: 10 }, admin)).json;
  const c = (await call('POST', '/api/customers', { name: 'Racer' }, admin)).json;
  const rs = await Promise.all(Array.from({ length: 8 }, () => call('POST', '/api/sales', { customer_id: c.id, items: [{ product_id: p.id, qty: 3 }] }, admin)));
  assert.equal(rs.filter(r => r.status === 201).length, 3);
  assert.equal(db.prepare('SELECT stock FROM products WHERE id=?').get(p.id).stock, 1);
});

test('invalid input is rejected', async () => {
  assert.equal((await call('POST', '/api/auth/register', { name: 'a', email: 'bad', password: 'longenoughpass' })).status, 400);
  assert.equal((await call('POST', '/api/auth/register', { name: 'a', email: 'a@b.co', password: 'short' })).status, 400);
  assert.equal((await call('POST', '/api/sales', { customer_id: 1, items: [] }, admin)).status, 400);
});
