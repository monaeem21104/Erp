# ERP Lite — نظام ERP صناعي مبسّط

Frontend + Backend + SQLite, **بدون أي dependencies** (Node 22.5+ فقط).
Arabic (RTL) / English (LTR) · Dark/green UI inspired by Vault.

## ما يعمل فعلاً (كله على قاعدة البيانات)
- تسجيل دخول/تسجيل حساب. التسجيل العام ينتج دور `user` دائماً (بدون أي صلاحيات على بيانات الشركة).
- أول أدمن يُنشأ من `ADMIN_EMAIL` / `ADMIN_PASSWORD` (أو كلمة مرور عشوائية تُطبع مرة واحدة في اللوج). لا يوجد باسورد افتراضي.
- أدوار: `admin` · `manager` · `staff` (قراءة فقط) · `user` (بدون صلاحيات). الصلاحيات تُفرض في الـ API وليس في الواجهة.
- المخزون: منتجات (AR/EN)، تسوية، سجل حركات (ledger)، ممنوع الرصيد السالب، تنبيه حد إعادة الطلب.
- المشتريات: أمر شراء ← استلام (يزيد المخزون ويحسب متوسط التكلفة).
- المبيعات: أمر بيع يخصم المخزون داخل transaction (لا overselling حتى مع طلبات متزامنة).
- العملاء والموردون، لوحة تحكم بأرقام حقيقية، إدارة المستخدمين، سجل مراجعة (Audit).

## تشغيل محلي
```bash
ADMIN_EMAIL=you@example.com ADMIN_PASSWORD='choose-a-long-password' npm start   # http://localhost:3000
npm test                                                                          # 7 اختبارات تكامل
```
لو تركت `ADMIN_PASSWORD` فارغاً تُولَّد كلمة مرور وتُطبع مرة واحدة في اللوج.

## النشر
**Vercel لا يشغّل SQLite/سيرفر دائم**، فالتقسيم الصحيح:
1. **Backend (+ الواجهة)** على Render / Railway / Fly / VPS باستخدام `Dockerfile`. اربط **Persistent Disk** على `/data` (وإلا ستضيع البيانات عند كل deploy). ضع `ADMIN_EMAIL` و`ADMIN_PASSWORD` في Environment Variables.
2. (اختياري) **الواجهة على Vercel**: عدّل `destination` في `vercel.json` إلى رابط الـ backend، ثم اربط الريبو بـ Vercel (Framework: Other، Output: `public`). الطلبات `/api/*` تُمرَّر للـ backend بنفس الدومين.

## GitHub
```bash
git init && git add . && git commit -m "ERP Lite"
git branch -M main && git remote add origin https://github.com/<you>/erp-lite.git && git push -u origin main
```

## حدود معروفة (صراحةً)
هذه نسخة MVP، وليست ERP كامل. غير موجود: المحاسبة (قيد مزدوج)، التصنيع/BOM، الموارد البشرية، الصيانة، المرتجعات، الفوترة الإلكترونية، سير الموافقات، MFA، إعادة تعيين كلمة المرور بالإيميل، فصل الشركات/الفروع/المخازن، التقارير/التصدير.
التجزئة بـ scrypt (مدمج في Node) بدلاً من Argon2id. الجلسات tokens في localStorage. SQLite مناسب لنسخة واحدة وحمل خفيف؛ للتوسع انتقل إلى PostgreSQL.
