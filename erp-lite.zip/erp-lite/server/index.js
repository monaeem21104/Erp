const http = require('http');
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const { open, tx } = require('./db');
const A = require('./auth');

const PUBLIC_DIR = path.join(__dirname, '..', 'public');
const MIME = { '.html': 'text/html; charset=utf-8', '.js': 'text/javascript', '.css': 'text/css', '.svg': 'image/svg+xml', '.json': 'application/json', '.ico': 'image/x-icon' };

class HttpError extends Error { constructor(status, msg) { super(msg); this.status = status; } }
const bad = (m) => new HttpError(400, m);
const toCents = (v) => { const n = Number(v); if (!Number.isFinite(n) || n < 0) throw bad('Invalid amount'); return Math.round(n * 100); };
const posInt = (v, name = 'qty') => { const n = Number(v); if (!Number.isInteger(n) || n <= 0) throw bad(`Invalid ${name}`); return n; };
const str = (v, name, max = 200, required = true) => {
  const s = typeof v === 'string' ? v.trim() : '';
  if (required && !s) throw bad(`${name} is required`);
  if (s.length > max) throw bad(`${name} too long`);
  return s;
};
const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

function createApp(db) {
  const audit = (user, action, target, detail) =>
    db.prepare('INSERT INTO audit_logs(user_id,action,target,detail) VALUES(?,?,?,?)')
      .run(user ? user.id : null, action, target || null, detail ? JSON.stringify(detail) : null);

  // --- simple in-memory login throttle (per email+ip) ---
  const fails = new Map();
  const throttled = (k) => { const f = fails.get(k); return f && f.n >= 5 && Date.now() - f.t < 15 * 60 * 1000; };
  const noteFail = (k) => { const f = fails.get(k); fails.set(k, { n: (f && Date.now() - f.t < 15 * 60 * 1000 ? f.n : 0) + 1, t: Date.now() }); };

  // --- first admin bootstrap (only if no users exist) ---
  function bootstrapAdmin(log = console.log) {
    if (db.prepare('SELECT COUNT(*) c FROM users').get().c > 0) return;
    const email = (process.env.ADMIN_EMAIL || 'admin@example.com').toLowerCase();
    let pw = process.env.ADMIN_PASSWORD;
    let generated = false;
    if (!pw) { pw = crypto.randomBytes(12).toString('base64url'); generated = true; }
    if (pw.length < 10) throw new Error('ADMIN_PASSWORD must be at least 10 characters');
    db.prepare("INSERT INTO users(name,email,password_hash,role) VALUES('Administrator',?,?,'admin')")
      .run(email, A.hashPassword(pw));
    log(`[bootstrap] Admin created: ${email}` + (generated ? ` | one-time password: ${pw}  (change it / store it now)` : ''));
  }

  // --- route table ---
  const routes = [];
  const route = (method, pattern, perm, handler) => {
    const keys = [];
    const re = new RegExp('^' + pattern.replace(/:(\w+)/g, (_, k) => { keys.push(k); return '([^/]+)'; }) + '$');
    routes.push({ method, re, keys, perm, handler });
  };

  // Auth (public)
  route('POST', '/api/auth/register', null, ({ body, ctx }) => {
    const name = str(body.name, 'name', 100), email = str(body.email, 'email', 200).toLowerCase();
    if (!EMAIL_RE.test(email)) throw bad('Invalid email');
    const pw = typeof body.password === 'string' ? body.password : '';
    if (pw.length < 10) throw bad('Password must be at least 10 characters');
    try {
      // role is ALWAYS 'user' for public registration; any role in the body is ignored
      const r = db.prepare("INSERT INTO users(name,email,password_hash,role) VALUES(?,?,?,'user')").run(name, email, A.hashPassword(pw));
      audit(null, 'auth.register', `user:${r.lastInsertRowid}`);
    } catch (e) { if (/UNIQUE/.test(e.message)) throw new HttpError(409, 'Email already registered'); throw e; }
    return { status: 201, data: { ok: true } };
  });
  route('POST', '/api/auth/login', null, ({ body, ctx }) => {
    const email = str(body.email, 'email').toLowerCase(), key = email + '|' + ctx.ip;
    if (throttled(key)) throw new HttpError(429, 'Too many attempts, try again later');
    const u = db.prepare('SELECT * FROM users WHERE email=?').get(email);
    const ok = u && A.verifyPassword(String(body.password || ''), u.password_hash);
    if (!ok || u.status !== 'active') { noteFail(key); audit(null, 'auth.login_failed', email); throw new HttpError(401, 'Invalid credentials'); }
    fails.delete(key);
    audit(u, 'auth.login', `user:${u.id}`);
    return { data: { token: A.createSession(db, u.id), user: pub(u) } };
  });
  route('POST', '/api/auth/logout', 'auth', ({ ctx }) => {
    db.prepare('DELETE FROM sessions WHERE token_hash=?').run(A.sha(ctx.token));
    return { data: { ok: true } };
  });
  const pub = (u) => ({ id: u.id, name: u.name, email: u.email, role: u.role, status: u.status, lang: u.lang, permissions: A.ROLE_PERMS[u.role] || [] });
  route('GET', '/api/me', 'auth', ({ ctx }) => ({ data: pub(ctx.user) }));
  route('PUT', '/api/me/lang', 'auth', ({ ctx, body }) => {
    if (!['en', 'ar'].includes(body.lang)) throw bad('Invalid language');
    db.prepare('UPDATE users SET lang=? WHERE id=?').run(body.lang, ctx.user.id);
    return { data: { lang: body.lang } };
  });

  // Dashboard (all numbers from DB)
  route('GET', '/api/dashboard', 'dashboard.read', () => {
    const one = (sql) => db.prepare(sql).get();
    const inv = one('SELECT COALESCE(SUM(stock*cost_cents),0) v, COUNT(*) n FROM products');
    const sales = one("SELECT COUNT(*) n, COALESCE(SUM(total_cents),0) t FROM sales_orders WHERE status='delivered'");
    const purch = one("SELECT COUNT(*) n, COALESCE(SUM(total_cents),0) t FROM purchase_orders WHERE status='received'");
    const pending = one("SELECT COUNT(*) n FROM purchase_orders WHERE status='ordered'");
    const low = db.prepare('SELECT id,sku,name_en,name_ar,stock,reorder_level FROM products WHERE stock<=reorder_level ORDER BY stock LIMIT 10').all();
    const recent = db.prepare(`SELECT m.id,m.qty,m.type,m.ref,m.created_at,p.name_en,p.name_ar,p.sku FROM stock_movements m
      JOIN products p ON p.id=m.product_id ORDER BY m.id DESC LIMIT 10`).all();
    const daily = db.prepare(`SELECT date(created_at) d, SUM(total_cents) t FROM sales_orders
      WHERE created_at >= date('now','-6 days') GROUP BY d ORDER BY d`).all();
    return { data: {
      products: inv.n, inventory_value_cents: inv.v,
      sales_orders: sales.n, revenue_cents: sales.t,
      purchases_received: purch.n, expenses_cents: purch.t,
      pending_purchase_orders: pending.n, low_stock: low, recent_movements: recent, sales_by_day: daily,
      customers: one('SELECT COUNT(*) n FROM customers').n, suppliers: one('SELECT COUNT(*) n FROM suppliers').n
    } };
  });

  // Simple master-data CRUD helper
  const searchLike = (q) => `%${String(q || '').replace(/[%_]/g, '')}%`;
  function party(table, perm) {
    route('GET', `/api/${table}`, `${perm}.read`, ({ query }) => ({ data: db.prepare(
      `SELECT * FROM ${table} WHERE name LIKE ? OR COALESCE(phone,'') LIKE ? OR COALESCE(email,'') LIKE ? ORDER BY id DESC LIMIT 500`)
      .all(...Array(3).fill(searchLike(query.q))) }));
    const fields = (b) => [str(b.name, 'name', 150), str(b.phone, 'phone', 50, false), str(b.email, 'email', 150, false), str(b.address, 'address', 300, false)];
    route('POST', `/api/${table}`, `${perm}.write`, ({ body, ctx }) => {
      const r = db.prepare(`INSERT INTO ${table}(name,phone,email,address) VALUES(?,?,?,?)`).run(...fields(body));
      audit(ctx.user, `${table}.create`, `${table}:${r.lastInsertRowid}`);
      return { status: 201, data: { id: Number(r.lastInsertRowid) } };
    });
    route('PUT', `/api/${table}/:id`, `${perm}.write`, ({ body, params, ctx }) => {
      const r = db.prepare(`UPDATE ${table} SET name=?,phone=?,email=?,address=? WHERE id=?`).run(...fields(body), params.id);
      if (!r.changes) throw new HttpError(404, 'Not found');
      audit(ctx.user, `${table}.update`, `${table}:${params.id}`);
      return { data: { ok: true } };
    });
    route('DELETE', `/api/${table}/:id`, `${perm}.write`, ({ params, ctx }) => {
      try { const r = db.prepare(`DELETE FROM ${table} WHERE id=?`).run(params.id); if (!r.changes) throw new HttpError(404, 'Not found'); }
      catch (e) { if (/FOREIGN KEY/.test(e.message)) throw new HttpError(409, 'Record is used by existing documents'); throw e; }
      audit(ctx.user, `${table}.delete`, `${table}:${params.id}`);
      return { data: { ok: true } };
    });
  }
  party('customers', 'customers');
  party('suppliers', 'suppliers');

  // Products & inventory
  route('GET', '/api/products', 'products.read', ({ query }) => ({ data: db.prepare(
    `SELECT * FROM products WHERE sku LIKE ? OR name_en LIKE ? OR name_ar LIKE ? ORDER BY id DESC LIMIT 500`)
    .all(...Array(3).fill(searchLike(query.q))) }));
  const prodFields = (b) => [str(b.sku, 'sku', 60), str(b.name_en, 'name_en', 150), str(b.name_ar, 'name_ar', 150, false),
    str(b.unit || 'pcs', 'unit', 20), toCents(b.price ?? 0), toCents(b.cost ?? 0), Number.isInteger(+b.reorder_level) && +b.reorder_level >= 0 ? +b.reorder_level : 0];
  route('POST', '/api/products', 'products.write', ({ body, ctx }) => {
    const f = prodFields(body);
    const opening = body.stock ? posInt(body.stock, 'stock') : 0;
    try {
      return tx(db, () => {
        const r = db.prepare('INSERT INTO products(sku,name_en,name_ar,unit,price_cents,cost_cents,reorder_level) VALUES(?,?,?,?,?,?,?)').run(...f);
        const id = Number(r.lastInsertRowid);
        if (opening) {
          db.prepare('UPDATE products SET stock=stock+? WHERE id=?').run(opening, id);
          db.prepare("INSERT INTO stock_movements(product_id,qty,type,ref,user_id) VALUES(?,?,'opening','initial stock',?)").run(id, opening, ctx.user.id);
        }
        audit(ctx.user, 'products.create', `product:${id}`);
        return { status: 201, data: { id } };
      });
    } catch (e) { if (/UNIQUE/.test(e.message)) throw new HttpError(409, 'SKU already exists'); throw e; }
  });
  route('PUT', '/api/products/:id', 'products.write', ({ body, params, ctx }) => {
    const f = prodFields(body);
    try {
      const r = db.prepare('UPDATE products SET sku=?,name_en=?,name_ar=?,unit=?,price_cents=?,cost_cents=?,reorder_level=? WHERE id=?').run(...f, params.id);
      if (!r.changes) throw new HttpError(404, 'Not found');
    } catch (e) { if (/UNIQUE/.test(e.message)) throw new HttpError(409, 'SKU already exists'); throw e; }
    audit(ctx.user, 'products.update', `product:${params.id}`);
    return { data: { ok: true } };
  });
  route('POST', '/api/products/:id/adjust', 'products.write', ({ body, params, ctx }) => {
    const delta = Number(body.qty);
    if (!Number.isInteger(delta) || delta === 0) throw bad('qty must be a non-zero integer');
    const reason = str(body.reason, 'reason', 200);
    return tx(db, () => {
      const p = db.prepare('SELECT stock FROM products WHERE id=?').get(params.id);
      if (!p) throw new HttpError(404, 'Not found');
      if (p.stock + delta < 0) throw new HttpError(409, 'Adjustment would make stock negative');
      db.prepare('UPDATE products SET stock=stock+? WHERE id=?').run(delta, params.id);
      db.prepare("INSERT INTO stock_movements(product_id,qty,type,ref,user_id) VALUES(?,?,'adjustment',?,?)").run(params.id, delta, reason, ctx.user.id);
      audit(ctx.user, 'inventory.adjust', `product:${params.id}`, { delta, reason });
      return { data: { stock: p.stock + delta } };
    });
  });
  route('GET', '/api/movements', 'products.read', () => ({ data: db.prepare(
    `SELECT m.*,p.sku,p.name_en,p.name_ar FROM stock_movements m JOIN products p ON p.id=m.product_id ORDER BY m.id DESC LIMIT 200`).all() }));

  // Sales: creating an order delivers goods immediately (stock out, atomic, no negative stock)
  route('GET', '/api/sales', 'sales.read', () => ({ data: db.prepare(
    `SELECT s.*,c.name customer FROM sales_orders s JOIN customers c ON c.id=s.customer_id ORDER BY s.id DESC LIMIT 200`).all() }));
  const items = (b) => {
    if (!Array.isArray(b.items) || !b.items.length || b.items.length > 100) throw bad('items required');
    const seen = new Set();
    return b.items.map(i => { const pid = posInt(i.product_id, 'product_id'); if (seen.has(pid)) throw bad('Duplicate product in items'); seen.add(pid); return { pid, qty: posInt(i.qty) , cost: i.unit_cost }; });
  };
  route('POST', '/api/sales', 'sales.write', ({ body, ctx }) => {
    const cid = posInt(body.customer_id, 'customer_id'), lines = items(body);
    return tx(db, () => {
      if (!db.prepare('SELECT 1 FROM customers WHERE id=?').get(cid)) throw bad('Customer not found');
      let total = 0; const prepared = [];
      for (const l of lines) {
        const p = db.prepare('SELECT id,price_cents,stock,sku FROM products WHERE id=?').get(l.pid);
        if (!p) throw bad(`Product ${l.pid} not found`);
        if (p.stock < l.qty) throw new HttpError(409, `Insufficient stock for ${p.sku} (available ${p.stock})`);
        total += p.price_cents * l.qty; prepared.push({ ...l, price: p.price_cents });
      }
      const so = db.prepare('INSERT INTO sales_orders(customer_id,total_cents,user_id) VALUES(?,?,?)').run(cid, total, ctx.user.id);
      const oid = Number(so.lastInsertRowid);
      for (const l of prepared) {
        db.prepare('INSERT INTO sales_items(order_id,product_id,qty,unit_price_cents) VALUES(?,?,?,?)').run(oid, l.pid, l.qty, l.price);
        db.prepare('UPDATE products SET stock=stock-? WHERE id=?').run(l.qty, l.pid);
        db.prepare("INSERT INTO stock_movements(product_id,qty,type,ref,user_id) VALUES(?,?,'sale',?,?)").run(l.pid, -l.qty, `SO-${oid}`, ctx.user.id);
      }
      audit(ctx.user, 'sales.create', `sales_order:${oid}`, { total });
      return { status: 201, data: { id: oid, total_cents: total } };
    });
  });
  route('GET', '/api/sales/:id', 'sales.read', ({ params }) => {
    const o = db.prepare('SELECT s.*,c.name customer FROM sales_orders s JOIN customers c ON c.id=s.customer_id WHERE s.id=?').get(params.id);
    if (!o) throw new HttpError(404, 'Not found');
    o.items = db.prepare('SELECT i.*,p.sku,p.name_en,p.name_ar FROM sales_items i JOIN products p ON p.id=i.product_id WHERE order_id=?').all(params.id);
    return { data: o };
  });

  // Purchasing: order -> receive (stock in)
  route('GET', '/api/purchases', 'purchases.read', () => ({ data: db.prepare(
    `SELECT o.*,s.name supplier FROM purchase_orders o JOIN suppliers s ON s.id=o.supplier_id ORDER BY o.id DESC LIMIT 200`).all() }));
  route('POST', '/api/purchases', 'purchases.write', ({ body, ctx }) => {
    const sid = posInt(body.supplier_id, 'supplier_id'), lines = items(body);
    return tx(db, () => {
      if (!db.prepare('SELECT 1 FROM suppliers WHERE id=?').get(sid)) throw bad('Supplier not found');
      let total = 0;
      const prepared = lines.map(l => {
        if (!db.prepare('SELECT 1 FROM products WHERE id=?').get(l.pid)) throw bad(`Product ${l.pid} not found`);
        const c = toCents(l.cost); total += c * l.qty; return { ...l, c };
      });
      const po = db.prepare('INSERT INTO purchase_orders(supplier_id,total_cents,user_id) VALUES(?,?,?)').run(sid, total, ctx.user.id);
      const oid = Number(po.lastInsertRowid);
      for (const l of prepared) db.prepare('INSERT INTO purchase_items(order_id,product_id,qty,unit_cost_cents) VALUES(?,?,?,?)').run(oid, l.pid, l.qty, l.c);
      audit(ctx.user, 'purchases.create', `purchase_order:${oid}`, { total });
      return { status: 201, data: { id: oid, total_cents: total } };
    });
  });
  route('POST', '/api/purchases/:id/receive', 'purchases.write', ({ params, ctx }) => tx(db, () => {
    const o = db.prepare('SELECT * FROM purchase_orders WHERE id=?').get(params.id);
    if (!o) throw new HttpError(404, 'Not found');
    if (o.status !== 'ordered') throw new HttpError(409, `Order is already ${o.status}`);
    for (const i of db.prepare('SELECT * FROM purchase_items WHERE order_id=?').all(o.id)) {
      // weighted-average cost
      const p = db.prepare('SELECT stock,cost_cents FROM products WHERE id=?').get(i.product_id);
      const newCost = Math.round((p.stock * p.cost_cents + i.qty * i.unit_cost_cents) / (p.stock + i.qty));
      db.prepare('UPDATE products SET stock=stock+?, cost_cents=? WHERE id=?').run(i.qty, newCost, i.product_id);
      db.prepare("INSERT INTO stock_movements(product_id,qty,type,ref,user_id) VALUES(?,?,'purchase',?,?)").run(i.product_id, i.qty, `PO-${o.id}`, ctx.user.id);
    }
    db.prepare("UPDATE purchase_orders SET status='received', received_at=CURRENT_TIMESTAMP WHERE id=?").run(o.id);
    audit(ctx.user, 'purchases.receive', `purchase_order:${o.id}`);
    return { data: { ok: true } };
  }));
  route('POST', '/api/purchases/:id/cancel', 'purchases.write', ({ params, ctx }) => {
    const r = db.prepare("UPDATE purchase_orders SET status='cancelled' WHERE id=? AND status='ordered'").run(params.id);
    if (!r.changes) throw new HttpError(409, 'Only open orders can be cancelled');
    audit(ctx.user, 'purchases.cancel', `purchase_order:${params.id}`);
    return { data: { ok: true } };
  });

  // Users & roles (admin only: '*' permission needed via users.manage)
  const ROLES = Object.keys(A.ROLE_PERMS);
  route('GET', '/api/users', 'users.manage', () => ({ data: db.prepare('SELECT id,name,email,role,status,created_at FROM users ORDER BY id').all() }));
  route('GET', '/api/roles', 'users.manage', () => ({ data: A.ROLE_PERMS }));
  route('POST', '/api/users', 'users.manage', ({ body, ctx }) => {
    const email = str(body.email, 'email').toLowerCase(); if (!EMAIL_RE.test(email)) throw bad('Invalid email');
    const role = body.role || 'user'; if (!ROLES.includes(role)) throw bad('Invalid role');
    const pw = typeof body.password === 'string' ? body.password : ''; if (pw.length < 10) throw bad('Password must be at least 10 characters');
    try {
      const r = db.prepare('INSERT INTO users(name,email,password_hash,role) VALUES(?,?,?,?)').run(str(body.name, 'name', 100), email, A.hashPassword(pw), role);
      audit(ctx.user, 'users.create', `user:${r.lastInsertRowid}`, { role });
      return { status: 201, data: { id: Number(r.lastInsertRowid) } };
    } catch (e) { if (/UNIQUE/.test(e.message)) throw new HttpError(409, 'Email already registered'); throw e; }
  });
  route('PUT', '/api/users/:id', 'users.manage', ({ body, params, ctx }) => tx(db, () => {
    const u = db.prepare('SELECT * FROM users WHERE id=?').get(params.id);
    if (!u) throw new HttpError(404, 'Not found');
    const role = body.role ?? u.role, status = body.status ?? u.status;
    if (!ROLES.includes(role)) throw bad('Invalid role');
    if (!['active', 'suspended'].includes(status)) throw bad('Invalid status');
    const losesAdmin = u.role === 'admin' && (role !== 'admin' || status !== 'active');
    if (losesAdmin && db.prepare("SELECT COUNT(*) c FROM users WHERE role='admin' AND status='active'").get().c <= 1)
      throw new HttpError(409, 'Cannot remove the last active administrator');
    db.prepare('UPDATE users SET role=?, status=? WHERE id=?').run(role, status, u.id);
    if (status !== 'active' || role !== u.role) db.prepare('DELETE FROM sessions WHERE user_id=?').run(u.id); // revoke sessions on critical change
    audit(ctx.user, 'users.update', `user:${u.id}`, { role_from: u.role, role_to: role, status_from: u.status, status_to: status });
    return { data: { ok: true } };
  }));
  route('POST', '/api/users/:id/password', 'users.manage', ({ body, params, ctx }) => {
    const pw = typeof body.password === 'string' ? body.password : ''; if (pw.length < 10) throw bad('Password must be at least 10 characters');
    const r = db.prepare('UPDATE users SET password_hash=? WHERE id=?').run(A.hashPassword(pw), params.id);
    if (!r.changes) throw new HttpError(404, 'Not found');
    db.prepare('DELETE FROM sessions WHERE user_id=?').run(params.id);
    audit(ctx.user, 'users.reset_password', `user:${params.id}`);
    return { data: { ok: true } };
  });
  route('GET', '/api/audit', 'users.manage', () => ({ data: db.prepare('SELECT a.*,u.email actor FROM audit_logs a LEFT JOIN users u ON u.id=a.user_id ORDER BY a.id DESC LIMIT 200').all() }));
  route('GET', '/api/health', null, () => ({ data: { ok: true } }));

  // --- request handling ---
  const readBody = (req) => new Promise((resolve, reject) => {
    let n = 0; const chunks = [];
    req.on('data', c => { n += c.length; if (n > 1e6) { reject(new HttpError(413, 'Payload too large')); req.destroy(); } else chunks.push(c); });
    req.on('end', () => { if (!chunks.length) return resolve({}); try { const j = JSON.parse(Buffer.concat(chunks)); resolve(j && typeof j === 'object' ? j : {}); } catch { reject(bad('Invalid JSON')); } });
    req.on('error', reject);
  });
  const send = (res, status, data, extra = {}) => {
    res.writeHead(status, { 'Content-Type': 'application/json; charset=utf-8', ...extra });
    res.end(JSON.stringify(data));
  };
  const SEC = { 'X-Content-Type-Options': 'nosniff', 'X-Frame-Options': 'DENY', 'Referrer-Policy': 'same-origin',
    'Content-Security-Policy': "default-src 'self'; style-src 'self' 'unsafe-inline'; img-src 'self' data:; connect-src 'self'" };

  async function handle(req, res) {
    const url = new URL(req.url, 'http://x');
    const origin = process.env.CORS_ORIGIN;
    const cors = origin ? { 'Access-Control-Allow-Origin': origin, 'Access-Control-Allow-Headers': 'Content-Type, Authorization', 'Access-Control-Allow-Methods': 'GET,POST,PUT,DELETE,OPTIONS', Vary: 'Origin' } : {};
    if (req.method === 'OPTIONS') { res.writeHead(204, cors); return res.end(); }

    if (!url.pathname.startsWith('/api/')) return serveStatic(url.pathname, res);

    try {
      const r = routes.find(r => r.method === req.method && r.re.test(url.pathname));
      if (!r) throw new HttpError(404, 'Not found');
      const m = r.re.exec(url.pathname), params = {}; r.keys.forEach((k, i) => params[k] = decodeURIComponent(m[i + 1]));
      const auth = req.headers.authorization || '', token = auth.startsWith('Bearer ') ? auth.slice(7) : null;
      const ctx = { ip: req.socket.remoteAddress, token, user: null };
      if (r.perm) {
        ctx.user = A.userFromToken(db, token);
        if (!ctx.user) throw new HttpError(401, 'Authentication required');
        if (r.perm !== 'auth' && !A.can(ctx.user.role, r.perm)) { audit(ctx.user, 'auth.forbidden', `${req.method} ${url.pathname}`); throw new HttpError(403, 'Forbidden'); }
      }
      const body = ['POST', 'PUT'].includes(req.method) ? await readBody(req) : {};
      const out = r.handler({ body, params, query: Object.fromEntries(url.searchParams), ctx });
      send(res, out.status || 200, out.data, { ...cors, ...SEC });
    } catch (e) {
      if (e instanceof HttpError) return send(res, e.status, { error: e.message }, { ...cors, ...SEC });
      console.error(e); send(res, 500, { error: 'Internal server error' }, { ...cors, ...SEC });
    }
  }

  function serveStatic(p, res) {
    let rel = decodeURIComponent(p === '/' ? '/index.html' : p);
    const file = path.normalize(path.join(PUBLIC_DIR, rel));
    if (!file.startsWith(PUBLIC_DIR)) { res.writeHead(403); return res.end(); }
    fs.readFile(file, (err, buf) => {
      if (err) { res.writeHead(404, { 'Content-Type': 'text/plain' }); return res.end('Not found'); }
      res.writeHead(200, { 'Content-Type': MIME[path.extname(file)] || 'application/octet-stream', ...SEC });
      res.end(buf);
    });
  }

  return { server: http.createServer(handle), bootstrapAdmin };
}

module.exports = { createApp };

if (require.main === module) {
  const db = open(process.env.DB_FILE || path.join(__dirname, '..', 'data', 'erp.db'));
  const app = createApp(db);
  app.bootstrapAdmin();
  const port = process.env.PORT || 3000;
  app.server.listen(port, () => console.log(`ERP running on http://localhost:${port}`));
  const stop = () => app.server.close(() => process.exit(0));
  process.on('SIGTERM', stop); process.on('SIGINT', stop);
}
