const crypto = require('crypto');

const ROLE_PERMS = {
  admin: ['*'],
  manager: ['dashboard.read', 'products.read', 'products.write', 'customers.read', 'customers.write',
    'suppliers.read', 'suppliers.write', 'sales.read', 'sales.write', 'purchases.read', 'purchases.write'],
  staff: ['dashboard.read', 'products.read', 'customers.read', 'suppliers.read', 'sales.read', 'purchases.read'],
  user: [] // default for public registration: no access to business data until an admin promotes
};
const can = (role, perm) => { const p = ROLE_PERMS[role] || []; return p.includes('*') || p.includes(perm); };

const SCRYPT = { N: 16384, r: 8, p: 1 };
function hashPassword(pw) {
  const salt = crypto.randomBytes(16);
  const h = crypto.scryptSync(pw, salt, 64, SCRYPT);
  return `scrypt$${salt.toString('hex')}$${h.toString('hex')}`;
}
function verifyPassword(pw, stored) {
  const [alg, s, h] = String(stored).split('$');
  if (alg !== 'scrypt' || !s || !h) return false;
  const calc = crypto.scryptSync(pw, Buffer.from(s, 'hex'), 64, SCRYPT);
  return crypto.timingSafeEqual(calc, Buffer.from(h, 'hex'));
}
const sha = t => crypto.createHash('sha256').update(t).digest('hex');

function createSession(db, userId) {
  const token = crypto.randomBytes(32).toString('hex');
  db.prepare('INSERT INTO sessions(token_hash,user_id,expires_at) VALUES(?,?,?)')
    .run(sha(token), userId, Date.now() + 12 * 3600 * 1000);
  return token;
}
function userFromToken(db, token) {
  if (!token) return null;
  const row = db.prepare(`SELECT u.id,u.name,u.email,u.role,u.status,u.lang,s.expires_at FROM sessions s
    JOIN users u ON u.id=s.user_id WHERE s.token_hash=?`).get(sha(token));
  if (!row || row.expires_at < Date.now() || row.status !== 'active') return null;
  return row;
}
module.exports = { ROLE_PERMS, can, hashPassword, verifyPassword, createSession, userFromToken, sha };
